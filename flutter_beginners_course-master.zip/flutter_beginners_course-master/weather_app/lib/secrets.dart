const openWeatherAPIKey = '4af409a4c67493e64a7c44c96d9c51e3';
